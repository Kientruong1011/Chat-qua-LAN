﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml;
using System.Net;

namespace TrayBalloon
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
        }
    }
}
